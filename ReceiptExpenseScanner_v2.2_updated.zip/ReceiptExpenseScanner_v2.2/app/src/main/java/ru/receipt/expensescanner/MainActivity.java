package ru.receipt.expensescanner;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.core.content.FileProvider;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import com.googlecode.tesseract.android.TessBaseAPI;

public class MainActivity extends Activity {
    private static final int REQ_CAMERA=10, REQ_GALLERY=11, REQ_CREATE_XLSX=20;
    private TextView status,result,details,monthTotal,monthProducts,monthAlcohol,budgetValue,budgetLeft,monthTitle;
    private final ArrayList<Row> rows=new ArrayList<>();
    private final ArrayList<Receipt> history=new ArrayList<>();
    private Uri cameraUri;
    private String currentDate="";
    private double currentTotal=0;
    private boolean currentSaved=false;
    private double monthlyBudget=0;
    private final ExecutorService ocrExecutor=Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b){ super.onCreate(b); setContentView(R.layout.activity_main);
        status=findViewById(R.id.status); result=findViewById(R.id.result); details=findViewById(R.id.details); monthTotal=findViewById(R.id.monthTotal); monthProducts=findViewById(R.id.monthProducts); monthAlcohol=findViewById(R.id.monthAlcohol); budgetValue=findViewById(R.id.budgetValue); budgetLeft=findViewById(R.id.budgetLeft); monthTitle=findViewById(R.id.monthTitle);
        loadHistory();
        monthlyBudget=getPreferences(0).getFloat("monthlyBudget",0);
        findViewById(R.id.scanButton).setOnClickListener(v->scan());
        findViewById(R.id.galleryButton).setOnClickListener(v->pickFromGallery());
        findViewById(R.id.addButton).setOnClickListener(v->editRow(null));
        findViewById(R.id.otherExpenseButton).setOnClickListener(v->addOtherExpense());
        findViewById(R.id.saveButton).setOnClickListener(v->saveReceipt());
        findViewById(R.id.exportButton).setOnClickListener(v->exportXlsx());
        findViewById(R.id.historyButton).setOnClickListener(v->showHistory());
        findViewById(R.id.dashboardButton).setOnClickListener(v->showDashboard());
        findViewById(R.id.budgetButton).setOnClickListener(v->{setBudget(); updateDashboardCards();});
        updateDashboardCards();
    }

    private void scan(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA); return; }
        try{
            File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"receipts"); dir.mkdirs();
            File f=new File(dir,"receipt_"+System.currentTimeMillis()+".jpg");
            cameraUri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE); i.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri); i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(i,REQ_CAMERA);
        }catch(Exception e){ Toast.makeText(this,"Не удалось открыть камеру: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int req,int code,@Nullable Intent data){ super.onActivityResult(req,code,data);
        if(req==REQ_CAMERA && code==RESULT_OK && cameraUri!=null){ status.setText("Распознавание чека…");
            try{ Bitmap bm=MediaStore.Images.Media.getBitmap(getContentResolver(),cameraUri); runOcr(bm); }
            catch(Exception e){ status.setText("Ошибка чтения фото"); Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show(); }
        } else if(req==REQ_GALLERY && code==RESULT_OK && data!=null && data.getData()!=null){
            status.setText("Распознавание чека из галереи…");
            try{
                Uri uri=data.getData();
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                Bitmap bm=MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                runOcr(bm);
            }catch(Exception e){
                try{ Bitmap bm=MediaStore.Images.Media.getBitmap(getContentResolver(),data.getData()); runOcr(bm); }
                catch(Exception ex){ status.setText("Не удалось открыть изображение"); Toast.makeText(this,"Не удалось открыть фото из галереи: "+ex.getMessage(),Toast.LENGTH_LONG).show(); }
            }
        } else if(req==REQ_CREATE_XLSX && code==RESULT_OK && data!=null){ writeXlsx(data.getData()); }
    }

    private void pickFromGallery(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{ startActivityForResult(i,REQ_GALLERY); }
        catch(Exception e){
            Intent fallback=new Intent(Intent.ACTION_GET_CONTENT); fallback.setType("image/*"); fallback.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(fallback,REQ_GALLERY);
        }
    }

    private void runOcr(Bitmap bm){
        status.setText("Распознавание русского чека…");
        final Bitmap prepared=prepareForOcr(bm);
        ocrExecutor.execute(()->{
            TessBaseAPI tess=new TessBaseAPI();
            String recognized="";
            try{
                File dataDir=prepareTessData();
                boolean ok=tess.init(dataDir.getAbsolutePath(),"rus+eng");
                if(!ok) throw new IOException("Не удалось загрузить русский OCR-модуль");
                tess.setPageSegMode(4);
                tess.setImage(prepared);
                String psm4=tess.getUTF8Text();
                tess.setPageSegMode(6);
                tess.setImage(prepared);
                String psm6=tess.getUTF8Text();
                tess.setPageSegMode(11);
                tess.setImage(prepared);
                String psm11=tess.getUTF8Text();
                recognized=chooseBestOcr(chooseBestOcr(psm4, psm6), psm11);
            }catch(Exception e){
                final String msg=e.getMessage()==null?e.toString():e.getMessage();
                runOnUiThread(()->{
                    status.setText("Ошибка русского OCR");
                    Toast.makeText(this,"Распознавание не удалось: "+msg,Toast.LENGTH_LONG).show();
                });
                return;
            }finally{
                try{tess.end();}catch(Exception ignored){}
            }
            final String text=recognized==null?"":recognized;
            runOnUiThread(()->parseReceipt(text));
        });
    }

    private File prepareTessData() throws IOException{
        File base=new File(getFilesDir(),"tesseract");
        File tessdata=new File(base,"tessdata");
        if(!tessdata.exists() && !tessdata.mkdirs()) throw new IOException("Не удалось создать папку OCR");
        copyAssetIfNeeded("tessdata/rus.traineddata",new File(tessdata,"rus.traineddata"));
        copyAssetIfNeeded("tessdata/eng.traineddata",new File(tessdata,"eng.traineddata"));
        return base;
    }

    private void copyAssetIfNeeded(String assetName,File target) throws IOException{
        if(target.exists() && target.length()>100000) return;
        try(InputStream in=getAssets().open(assetName); OutputStream out=new FileOutputStream(target)){
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0) out.write(buf,0,n);
        }
    }

    private Bitmap prepareForOcr(Bitmap src){
        int targetWidth=Math.max(1800,src.getWidth());
        int targetHeight=Math.max(1,(int)Math.round(src.getHeight()*(targetWidth/(double)src.getWidth())));
        Bitmap scaled=Bitmap.createScaledBitmap(src,targetWidth,targetHeight,true);
        Bitmap gray=Bitmap.createBitmap(scaled.getWidth(),scaled.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(gray);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        ColorMatrix cm=new ColorMatrix();
        cm.setSaturation(0f);
        ColorMatrix contrast=new ColorMatrix(new float[]{
                1.55f,0,0,0,-70,
                0,1.55f,0,0,-70,
                0,0,1.55f,0,-70,
                0,0,0,1,0});
        cm.postConcat(contrast);
        paint.setColorFilter(new ColorMatrixColorFilter(cm));
        canvas.drawColor(Color.WHITE);
        canvas.drawBitmap(scaled,0,0,paint);
        if(scaled!=src) scaled.recycle();
        return gray;
    }

    private String chooseBestOcr(String a,String b){
        if(a==null) a=""; if(b==null) b="";
        int sa=scoreOcr(a), sb=scoreOcr(b);
        return sa>=sb?a:b;
    }
    private int scoreOcr(String t){
        int score=0;
        if(t==null)return score;
        for(String raw:t.split("\\r?\\n")){
            String line=normalizeOcrLine(raw);
            String u=line.toUpperCase(Locale.ROOT);
            boolean moneyLine=line.matches(".*\\d+(?:[\\.,]\\d+)?\\s*(?:[*xхХ×]|%)\\s*\\d+(?:[\\.,]\\d+)?(?:\\s*(?:=|—|-)\\s*\\d+(?:[\\.,]\\d+)?)?.*");
            boolean hasCyr=line.matches(".*[А-Яа-яЁё].*");
            if(moneyLine && hasCyr) score+=12;
            else if(moneyLine) score+=4;
            if(isAlcohol(line)) score+=8;
            if(u.contains("НАИМЕНОВАНИЕ")) score+=2;
            if(u.contains("ИТОГО") || u.contains("СУММА НДС") || u.contains("БЕЗНАЛИЧНЫМИ")) score-=3;
            if(line.matches(".*\\d{2}\\.\\d{2}\\.\\d{2,4}.*")) score+=2;
        }
        return score;
    }
    private String normalizeOcrLine(String line){
        return line.replace('×','x').replace('Х','x').replace('х','x').replace('—','-').replace('−','-').replaceAll("\\s+"," ").trim();
    }
    private boolean isNoiseLine(String s){
        String u=s.toUpperCase(Locale.ROOT);
        return u.equals("ИТОГО") || u.startsWith("ИТОГО К") || u.startsWith("БЕЗНАЛИЧ") || u.startsWith("СУММА НДС") || u.startsWith("КАССА") || u.startsWith("НАИМЕНОВАНИЕ");
    }

    private void parseReceipt(String text){
        rows.clear(); currentTotal=0; currentSaved=false;
        String date=find(text,"(\\d{2}\\.\\d{2}\\.\\d{2,4})");
        if(date==null) date=new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(new Date());
        currentDate=normalizeDate(date);

        // Российские чеки часто печатают название товара на одной строке,
        // а количество/цену — на следующей. Для аптечных чеков это особенно типично:
        // "КЕТОРОЛ ЭКСПРЕСС..." -> "1 шт. x 194.00 ..." -> "=194.00 НДС 10%".
        Pattern full=Pattern.compile("(.+?)\\s+(\\d+(?:[\\.,]\\d+)?)\\s*(?:[*xхХ×]|%)\\s*(\\d+(?:[\\.,]\\d+)?)\\s*(?:=|—|-)\\s*(\\d+(?:[\\.,]\\d+)?)\\s*$");
        Pattern simple=Pattern.compile("(.+?)\\s+(\\d+(?:[\\.,]\\d+)?)\\s*(?:[*xхХ×]|%)\\s*(\\d+(?:[\\.,]\\d+)?)\\s*$");
        Pattern qtyPrice=Pattern.compile("^\\s*(\\d+(?:[\\.,]\\d+)?)\\s*(?:шт\\.?|штук|ед\\.?|кг|г|л|мл)?\\s*(?:[*xхХ×]|%)\\s*(\\d+(?:[\\.,]\\d+)?)\\b.*$",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
        Pattern onlySum=Pattern.compile("^\\s*(?:=|—|-)?\\s*(\\d+(?:[\\.,]\\d+)?)\\s*(?:НДС|НАС|VAT|%)?.*$",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
        Pattern qtyUnitPriceNoEquals=Pattern.compile("^\\s*(\\d+(?:[\\.,]\\d+)?)\\s*(?:шт\\.?|штук|ед\\.?|кг|г|л|мл)?\\s*(?:[*xхХ×]|%)\\s*(\\d+(?:[\\.,]\\d+)?)(?:\\s+|$).*$",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);

        String pendingName=null;
        Double pendingQty=null, pendingUnit=null;

        String[] lines=text.split("\\r?\\n");
        for(int i=0;i<lines.length;i++){
            String line=normalizeOcrLine(lines[i]);
            if(line.isEmpty()) continue;

            Matcher m=full.matcher(line);
            if(m.find()){
                String name=cleanItemName(m.group(1));
                double qty=toNum(m.group(2)), unit=toNum(m.group(3)), sum=toNum(m.group(4));
                if(validItem(name,sum)){
                    addParsedRow(name,unit,qty,sum);
                    pendingName=null; pendingQty=null; pendingUnit=null;
                    continue;
                }
            }

            m=simple.matcher(line);
            if(m.find()){
                String name=cleanItemName(m.group(1));
                double qty=toNum(m.group(2)), unit=toNum(m.group(3));
                if(validItem(name,unit)){
                    addParsedRow(name,unit,qty,unit*qty);
                    pendingName=null; pendingQty=null; pendingUnit=null;
                    continue;
                }
            }

            // Detect the second line of a two-line product entry.
            m=qtyPrice.matcher(line);
            if(m.find() && pendingName!=null){
                pendingQty=toNum(m.group(1));
                pendingUnit=toNum(m.group(2));
                // Some cash-registers print the final price on the same line,
                // but pharmacy receipts often print it on the following line.
                Matcher sameLineSum=Pattern.compile("=\\s*(\\d+(?:[\\.,]\\d+)?)").matcher(line);
                if(sameLineSum.find()){
                    double sum=toNum(sameLineSum.group(1));
                    if(sum>0) addParsedRow(pendingName,pendingUnit,pendingQty,sum);
                    pendingName=null; pendingQty=null; pendingUnit=null;
                }
                continue;
            }

            // If OCR lost the multiplication sign or equals sign, accept a plausible
            // quantity + unit-price line and use quantity*unit as the line cost.
            if(m==null || !m.find()){
                Matcher fallback=qtyUnitPriceNoEquals.matcher(line);
                if(fallback.find() && pendingName!=null){
                    double q=toNum(fallback.group(1)), u=toNum(fallback.group(2));
                    if(q>0 && u>0 && q<10000 && u<1000000){
                        addParsedRow(pendingName,u,q,u*q);
                        pendingName=null; pendingQty=null; pendingUnit=null;
                        continue;
                    }
                }
            }

            if(pendingName!=null && pendingQty!=null && pendingUnit!=null){
                Matcher sm=onlySum.matcher(line);
                if(sm.find()){
                    double sum=toNum(sm.group(1));
                    // Ignore lines that are clearly tax-only totals or receipt total sections.
                    String u=line.toUpperCase(Locale.ROOT);
                    if(sum>0 && !u.contains("ИТОГО") && !u.contains("СУММА")){
                        addParsedRow(pendingName,pendingUnit,pendingQty,sum);
                        pendingName=null; pendingQty=null; pendingUnit=null;
                        continue;
                    }
                }
            }

            // Keep plausible Cyrillic item names as a candidate for the next quantity/price line.
            String candidate=cleanItemName(line);
            if(isPotentialItemName(candidate)){
                pendingName=candidate;
                pendingQty=null; pendingUnit=null;
            } else if(isNoiseLine(candidate)){
                pendingName=null; pendingQty=null; pendingUnit=null;
            }
        }

        // If a final product did not have a separate total line, use quantity * unit price.
        if(pendingName!=null && pendingQty!=null && pendingUnit!=null){
            double sum=pendingQty*pendingUnit;
            if(sum>0) addParsedRow(pendingName,pendingUnit,pendingQty,sum);
        }

        render();
        updateDashboardCards();
        if(rows.isEmpty()){
            status.setText("Фото получено. Не удалось уверенно распознать позиции.");
            Toast.makeText(this,"Попробуйте сфотографировать чек крупнее и ровнее.",Toast.LENGTH_LONG).show();
        } else {
            status.setText("Распознано позиций: "+rows.size()+". Проверьте чек и нажмите «Сохранить».");
        }
    }

    private void addParsedRow(String name,double unit,double qty,double sum){
        if(!validItem(name,sum)) return;
        boolean alcohol=isAlcohol(name);
        rows.add(new Row(name,unit,qty,sum,alcohol,autoCategory(name)));
        currentTotal+=sum;
    }

    private boolean validItem(String name,double value){
        return name!=null && name.length()>=2 && value>0 && value<1000000 && !isNoiseLine(name);
    }

    private String cleanItemName(String s){
        if(s==null) return "";
        return s.replaceAll("\\s+"," ")
                .replaceAll("^[\\s\\-_=:+]+","")
                .replaceAll("\\s+(?:НДС|НАС)\\s*\\d{1,2}[\\.,]?\\d*%?.*$","")
                .trim();
    }

    private boolean isPotentialItemName(String s){
        if(s==null || s.length()<3) return false;
        String u=s.toUpperCase(Locale.ROOT);
        if(isNoiseLine(s)) return false;
        if(u.contains("МЕСТО РАСЧЕТОВ") || u.contains("ИНН ") || u.contains("ЗН ККТ") ||
           u.contains("КАССОВЫЙ ЧЕК") || u.contains("ПРИХОД") || u.contains("КАССИР") ||
           u.contains("НАЛОГ") || u.contains("НДС") || u.contains("ОПЛАТ") ||
           u.contains("РН ККТ") || u.contains("ФН ") || u.contains("ФД ") || u.contains("ФПД ")) return false;
        // A candidate should contain Cyrillic and not be a line made mostly of numbers.
        return s.matches(".*[А-Яа-яЁё].*") && !s.matches(".*\\d{5,}.*");
    }

    private void render(){
        StringBuilder s=new StringBuilder("Дата: ").append(currentDate).append("\n\n");
        double pt=0,at=0;
        for(int i=0;i<rows.size();i++){ Row r=rows.get(i); s.append(i+1).append(". ").append(r.alcohol?"🍺 ":"🛒 ").append(r.name)
          .append(" — цена ").append(fmt(r.unit)).append(" ₽; кол-во ").append(fmtQty(r.qty)).append("; стоимость ").append(fmt(r.sum)).append(" ₽\n"); if(r.alcohol) at+=r.sum; else pt+=r.sum; }
        currentTotal=pt+at;
        s.append("\nПродукты: ").append(fmt(pt)).append(" ₽\nАлкоголь: ").append(fmt(at)).append(" ₽\nВСЕГО: ").append(fmt(currentTotal)).append(" ₽");
        result.setText(s.toString()); details.setText("Нажмите на «Добавить», чтобы внести или исправить позицию. Для исправления существующей строки выберите её в списке ниже.");
        result.setOnClickListener(v->showRowsEditor());
    }

    private void showRowsEditor(){
        if(rows.isEmpty()){ editRow(null); return; }
        String[] a=new String[rows.size()]; for(int i=0;i<rows.size();i++) a[i]=(i+1)+". "+rows.get(i).name;
        new AlertDialog.Builder(this).setTitle("Выберите позицию").setItems(a,(d,w)->{
            new AlertDialog.Builder(this).setTitle(rows.get(w).name)
                    .setItems(new String[]{"Изменить","Удалить"},(dd,action)->{
                        if(action==0) editRow(w);
                        else { rows.remove((int)w); render(); status.setText("Позиция удалена. Проверьте чек и нажмите «Сохранить»."); }
                    }).setNegativeButton("Отмена",null).show();
        }).setNegativeButton("Отмена",null).show();
    }
    private void editRow(@Nullable Integer index){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
        EditText name=new EditText(this); name.setHint("Название товара");
        EditText qty=new EditText(this); qty.setHint("Количество / вес"); qty.setInputType(2|8192);
        EditText price=new EditText(this); price.setHint("Цена за единицу / кг"); price.setInputType(2|8192);
        EditText category=new EditText(this); category.setHint("Категория (Продукты, Быт, Транспорт…)");
        CheckBox alc=new CheckBox(this); alc.setText("Спиртное");
        if(index!=null){ Row r=rows.get(index); name.setText(r.name); qty.setText(fmtQty(r.qty)); price.setText(fmt(r.unit)); category.setText(r.category); alc.setChecked(r.alcohol); }
        box.addView(name); box.addView(qty); box.addView(price); box.addView(category); box.addView(alc);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(index==null?"Добавить позицию":"Изменить позицию").setView(box)
          .setPositiveButton("Сохранить",null).setNegativeButton("Отмена",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{ String n=name.getText().toString().trim(); if(n.isEmpty()) throw new Exception("Название пустое"); double q=toNum(qty.getText().toString()), p=toNum(price.getText().toString());
                Row r=new Row(n,p,q,p,alc.isChecked(),category.getText().toString().trim().isEmpty()?autoCategory(n):category.getText().toString().trim()); if(index==null) rows.add(r); else rows.set(index,r); render(); dlg.dismiss();
            }catch(Exception e){ Toast.makeText(this,"Проверьте количество и цену",Toast.LENGTH_SHORT).show(); }
        })); dlg.show();
    }

    private void addOtherExpense(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
        EditText name=new EditText(this); name.setHint("Например: билет на поезд, театр, кино");
        EditText amount=new EditText(this); amount.setHint("Сумма, ₽"); amount.setInputType(2|8192);
        EditText category=new EditText(this); category.setHint("Категория: Транспорт, Кино, Театр, Билеты…");
        box.addView(name); box.addView(amount); box.addView(category);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Добавить расход").setMessage("Расход без чека: билет, кино, театр, транспорт и т.п.")
          .setView(box).setPositiveButton("Добавить",null).setNegativeButton("Отмена",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{ String n=name.getText().toString().trim(); double sum=toNum(amount.getText().toString());
                if(n.isEmpty()||sum<=0) throw new Exception(); String c=category.getText().toString().trim();
                if(c.isEmpty()) c=autoCategory(n); rows.add(new Row(n,sum,1,sum,false,c)); currentDate=new SimpleDateFormat("dd.MM.yyyy",Locale.US).format(new Date()); currentSaved=false; render(); updateDashboardCards(); dlg.dismiss();
            }catch(Exception e){Toast.makeText(this,"Введите название и сумму",Toast.LENGTH_SHORT).show();}
        })); dlg.show();
    }

    private void saveReceipt(){ if(rows.isEmpty()){ Toast.makeText(this,"Нет позиций для сохранения",Toast.LENGTH_SHORT).show(); return; }
        double pt=0,at=0; for(Row r:rows){if(r.alcohol)at+=r.sum;else pt+=r.sum;} history.add(new Receipt(currentDate,rows)); saveHistory(); currentSaved=true; status.setText("Чек сохранён. Всего: "+fmt(pt+at)+" ₽"); updateDashboardCards();
    }

    private void exportXlsx(){
        if(rows.isEmpty() && history.isEmpty()){ Toast.makeText(this,"Сначала добавьте или сохраните чек",Toast.LENGTH_SHORT).show(); return; }
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        i.putExtra(Intent.EXTRA_TITLE,"Расходы_"+new SimpleDateFormat("yyyy-MM-dd_HH-mm",Locale.US).format(new Date())+".xlsx"); startActivityForResult(i,REQ_CREATE_XLSX);
    }

    private void writeXlsx(Uri uri){ try{
        ArrayList<Receipt> export=new ArrayList<>(history);
        if(!rows.isEmpty() && !currentSaved) export.add(new Receipt(currentDate,rows));
        XlsxExporter.write(uri, getContentResolver(), export);
        Toast.makeText(this,"Excel-файл сохранён: чеков "+export.size(),Toast.LENGTH_LONG).show();
    }catch(Exception e){ Toast.makeText(this,"Ошибка экспорта: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private void showDashboard(){
        Calendar now=Calendar.getInstance();
        int month=now.get(Calendar.MONTH)+1, year=now.get(Calendar.YEAR);
        double product=0, alcohol=0, total=0;
        int receipts=0;
        LinkedHashMap<String,Double> cats=new LinkedHashMap<>();
        for(Receipt r:history){
            if(!sameMonth(r.date,year,month)) continue;
            receipts++;
            for(Row x:r.rows){ total+=x.sum; if(x.alcohol) alcohol+=x.sum; else product+=x.sum; String c=x.category==null||x.category.isEmpty()?autoCategory(x.name):x.category; cats.put(c,cats.containsKey(c)?cats.get(c)+x.sum:x.sum); }
        }
        if(!rows.isEmpty() && !currentSaved && sameMonth(currentDate,year,month)){
            for(Row x:rows){ total+=x.sum; if(x.alcohol) alcohol+=x.sum; else product+=x.sum; String c=x.category==null||x.category.isEmpty()?autoCategory(x.name):x.category; cats.put(c,cats.containsKey(c)?cats.get(c)+x.sum:x.sum); }
            receipts++;
        }
        StringBuilder s=new StringBuilder();
        s.append("РАСХОДЫ ЗА ").append(String.format(Locale.US,"%02d.%04d",month,year)).append("\n\n");
        s.append("Всего: ").append(fmt(total)).append(" ₽\n");
        s.append("Продукты: ").append(fmt(product)).append(" ₽\n");
        s.append("Алкоголь: ").append(fmt(alcohol)).append(" ₽\n");
        s.append("Чеков: ").append(receipts).append("\n");
        s.append("Доля алкоголя: ").append(fmt(total==0?0:(alcohol*100.0/total))).append(" %\n\n");
        s.append("ПО КАТЕГОРИЯМ:\n");
        for(Map.Entry<String,Double> e:cats.entrySet()) s.append("• ").append(e.getKey()).append(": ").append(fmt(e.getValue())).append(" ₽\n");
        s.append("\n");
        if(monthlyBudget>0){
            double left=monthlyBudget-total;
            s.append("Бюджет: ").append(fmt(monthlyBudget)).append(" ₽\n");
            s.append(left>=0?"Осталось: ":"Превышение: ").append(fmt(Math.abs(left))).append(" ₽\n");
            double pct=total*100.0/monthlyBudget;
            s.append("Использовано: ").append(fmt(pct)).append(" %\n\n");
            if(pct>=100) s.append("⚠ Бюджет уже превышен.\n\n"); else if(pct>=80) s.append("⚠ Вы использовали более 80% бюджета.\n\n");
        } else s.append("Бюджет не задан. Нажмите «Месячный бюджет», чтобы установить лимит.\n\n");
        s.append("Совет: открывайте статистику перед покупками — так проще замечать повторяющиеся необязательные траты.");
        new AlertDialog.Builder(this).setTitle("Куда уходят деньги?").setMessage(s.toString()).setPositiveButton("OK",null).show();
    }

    private void setBudget(){
        final EditText input=new EditText(this);
        input.setHint("Например, 30000");
        input.setInputType(2|8192);
        if(monthlyBudget>0) input.setText(fmt(monthlyBudget));
        new AlertDialog.Builder(this).setTitle("Месячный бюджет").setMessage("Установите максимальную сумму расходов на месяц. Введите 0, чтобы отключить бюджет.")
          .setView(input).setPositiveButton("Сохранить",(d,w)->{
              try{ monthlyBudget=toNum(input.getText().toString()); if(monthlyBudget<0) monthlyBudget=0; getPreferences(0).edit().putFloat("monthlyBudget",(float)monthlyBudget).apply(); updateDashboardCards(); Toast.makeText(this,monthlyBudget>0?"Бюджет сохранён":"Бюджет отключён",Toast.LENGTH_SHORT).show(); }
              catch(Exception e){ Toast.makeText(this,"Введите сумму, например 30000",Toast.LENGTH_SHORT).show(); }
          }).setNegativeButton("Отмена",null).show();
    }


    private void updateDashboardCards(){
        Calendar now=Calendar.getInstance(); int month=now.get(Calendar.MONTH)+1, year=now.get(Calendar.YEAR);
        double product=0, alcohol=0, total=0;
        for(Receipt r:history){ if(!sameMonth(r.date,year,month)) continue; for(Row x:r.rows){ total+=x.sum; if(x.alcohol) alcohol+=x.sum; else product+=x.sum; } }
        if(!rows.isEmpty() && !currentSaved && sameMonth(currentDate,year,month)){ for(Row x:rows){ total+=x.sum; if(x.alcohol) alcohol+=x.sum; else product+=x.sum; } }
        monthTitle.setText("РАСХОДЫ ЗА "+String.format(Locale.US,"%02d.%04d",month,year));
        monthTotal.setText(fmt(total)+" ₽"); monthProducts.setText(fmt(product)+" ₽"); monthAlcohol.setText(fmt(alcohol)+" ₽");
        if(monthlyBudget>0){ budgetValue.setText(fmt(monthlyBudget)+" ₽"); double left=monthlyBudget-total; budgetLeft.setText((left>=0?"":"−")+fmt(Math.abs(left))+" ₽"); }
        else { budgetValue.setText("Не задан"); budgetLeft.setText("—"); }
    }

    private static boolean sameMonth(String date,int year,int month){
        try{ String[] p=date.split("\\."); if(p.length<3)return false; int y=Integer.parseInt(p[2]); if(y<100)y+=2000; return y==year && Integer.parseInt(p[1])==month; }
        catch(Exception e){return false;}
    }

    private void showHistory(){
        if(history.isEmpty()){ new AlertDialog.Builder(this).setMessage("История пока пуста.").setPositiveButton("OK",null).show(); return; }
        final ArrayList<Receipt> filtered=new ArrayList<>(history);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,8,24,0);
        EditText search=new EditText(this); search.setHint("Поиск: магазин, товар, категория или сумма");
        Button dateBtn=new Button(this); dateBtn.setText("📅 Выбрать дату");
        Button clearBtn=new Button(this); clearBtn.setText("Сбросить фильтр");
        ListView list=new ListView(this);
        box.addView(search); box.addView(dateBtn); box.addView(clearBtn); box.addView(list,new LinearLayout.LayoutParams(-1,520));
        final String[] dateFilter={""};
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("История чеков").setView(box).setNegativeButton("Закрыть",null).create();
        Runnable refresh=()->{
            String q=search.getText().toString().trim().toLowerCase(Locale.ROOT); filtered.clear();
            for(Receipt r:history){ if(!dateFilter[0].isEmpty()&&!r.date.equals(dateFilter[0]))continue; StringBuilder hay=new StringBuilder(r.date); double total=0; for(Row x:r.rows){hay.append(' ').append(x.name).append(' ').append(x.category); total+=x.sum;} hay.append(' ').append(fmt(total)); if(q.isEmpty()||hay.toString().toLowerCase(Locale.ROOT).contains(q)) filtered.add(r); }
            String[] a=new String[filtered.size()]; for(int i=0;i<filtered.size();i++){Receipt r=filtered.get(i); double t=0;for(Row x:r.rows)t+=x.sum;a[i]=r.date+" — "+fmt(t)+" ₽ ("+r.rows.size()+" поз.)";}
            list.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,a));
        };
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){refresh.run();} public void afterTextChanged(android.text.Editable e){}});
        dateBtn.setOnClickListener(v->{Calendar c=Calendar.getInstance(); new DatePickerDialog(this,(view,y,m,d)->{dateFilter[0]=String.format(Locale.US,"%02d.%02d.%04d",d,m+1,y); dateBtn.setText("📅 "+dateFilter[0]); refresh.run();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();});
        clearBtn.setOnClickListener(v->{dateFilter[0]=""; search.setText(""); dateBtn.setText("📅 Выбрать дату"); refresh.run();});
        list.setOnItemClickListener((parent,view,position,id)->{Receipt r=filtered.get(position);rows.clear();rows.addAll(r.rows);currentDate=r.date;currentSaved=true;render();status.setText("Загружен чек из истории");dlg.dismiss();});
        dlg.setOnShowListener(x->refresh.run()); dlg.show();
    }

    private void saveHistory(){ StringBuilder all=new StringBuilder(); for(Receipt r:history){all.append(escape(r.date)).append("\t"); for(Row x:r.rows){all.append(escape(x.name)).append("|").append(x.unit).append("|").append(x.qty).append("|").append(x.sum).append("|").append(x.alcohol?1:0).append("|").append(escape(x.category==null?"":x.category)).append(";;");} all.append("\n");} getPreferences(0).edit().putString("history",all.toString()).apply(); }
    private void loadHistory(){ String all=getPreferences(0).getString("history",""); if(all.isEmpty())return; for(String line:all.split("\\n")){if(line.trim().isEmpty())continue;String[] z=line.split("\\t",2);if(z.length<2)continue;Receipt r=new Receipt(unescape(z[0]),new ArrayList<>());for(String q:z[1].split(";;")){if(q.isEmpty())continue;String[] f=q.split("\\|",-1);if(f.length<5)continue;try{String cat=f.length>=6?unescape(f[5]):autoCategory(unescape(f[0])); r.rows.add(new Row(unescape(f[0]),Double.parseDouble(f[1]),Double.parseDouble(f[2]),Double.parseDouble(f[3]),"1".equals(f[4]),cat));}catch(Exception ignored){}}history.add(r);} }
    private static String escape(String s){return Base64.getEncoder().encodeToString(s.getBytes());} private static String unescape(String s){try{return new String(Base64.getDecoder().decode(s));}catch(Exception e){return s;}}
    private static String normalizeDate(String date){
        try{ String[] p=date.split("\\."); int y=Integer.parseInt(p[2]); if(p[2].length()==2) y+=2000; return String.format(Locale.US,"%02d.%02d.%04d",Integer.parseInt(p[0]),Integer.parseInt(p[1]),y); }
        catch(Exception e){ return date; }
    }
    private static String find(String s,String re){Matcher m=Pattern.compile(re).matcher(s);return m.find()?m.group(1):null;} private static double toNum(String s){return Double.parseDouble(s.trim().replace(',','.'));}
    private static boolean isAlcohol(String s){
        if(s==null)return false;
        String q=s.toLowerCase(Locale.ROOT).replace('ё','е').replaceAll("[^а-яa-z0-9]+"," ").trim();
        String[] a={"пиво","пив","лагер","эль","портер","стаут","сидр","вино","вин","водка","водк","коньяк","конья","виски","виск","бренди","бренд","шампан","игрист","ликер","ликёр","ром","джин","текил","вермут","настойк","наливк","алкогол","самогон","аперитив"};
        for(String x:a)if(q.contains(x))return true;
        // Common OCR distortions seen on thermal receipts.
        return q.contains("пиво") || q.matches(".*\bпив[оа]\b.*") || q.contains("виск") || q.contains("водк");
    }
    private static String fmt(double x){return String.format(Locale.US,"%.2f",x).replace('.',',');} private static String fmtQty(double x){return String.format(Locale.US,"%.3f",x).replaceAll("0+$","").replaceAll("\\.$","").replace('.',',');}
    private static String autoCategory(String s){String q=s.toLowerCase(Locale.ROOT); if(isAlcohol(s)) return "Алкоголь"; String[][] m={{"Молочные продукты","молок","кефир","сыр","сметан","масл"},{"Мясо и колбасы","мяс","сосиск","колбас","фарш","куриц"},{"Овощи и фрукты","яблок","томат","огур","картоф","банан","капуст"},{"Хлеб и выпечка","хлеб","батон","булоч","печен"},{"Сладости","шоколад","конфет","торт","печень"},{"Бытовые товары","порошок","моющ","губк","туалет","салфет"},{"Напитки","сок","вода","кола","напиток","чай","кофе"},{"Транспорт","бензин","топлив"}}; for(String[] row:m){for(int i=1;i<row.length;i++)if(q.contains(row[i]))return row[0];} return "Прочее";}
    @Override protected void onDestroy(){ super.onDestroy(); ocrExecutor.shutdownNow(); }

    public static class Row{String name;double unit,qty,sum;boolean alcohol;String category;Row(String n,double u,double q,double s,boolean a,String c){name=n;unit=u;qty=q;sum=s;alcohol=a;category=c;}}
    public static class Receipt{public String date; public ArrayList<Row> rows; public Receipt(String d,List<Row> r){date=d;rows=new ArrayList<>(r);}}
}
