package ru.receipt.expensescanner;

import android.content.ContentResolver;
import android.net.Uri;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

public final class XlsxExporter {
    private XlsxExporter() {}
    private static String esc(String s){ return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
    private static String col(int n){ StringBuilder s=new StringBuilder(); while(n>0){ n--; s.insert(0,(char)('A'+n%26)); n/=26;} return s.toString(); }
    private static void put(ZipOutputStream z,String name,String data)throws IOException{ z.putNextEntry(new ZipEntry(name)); z.write(data.getBytes(StandardCharsets.UTF_8)); z.closeEntry(); }

    public static void write(Uri uri, ContentResolver resolver, List<MainActivity.Receipt> receipts) throws IOException {
        StringBuilder sheet=new StringBuilder();
        sheet.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
             .append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");
        String[] headers={"Дата покупки","Продукты","Цена","Количество","Спиртное","Цена","Количество","Всего трат"};
        sheet.append("<row r=\"1\">");
        for(int c=0;c<headers.length;c++){
            int style = c==1 ? 1 : (c==3 || c==6 ? 2 : (c==4 ? 3 : (c==7 ? 4 : 0)));
            sheet.append(inlineCell(c+1,1,headers[c],style));
        }
        sheet.append("</row>");
        int rowNum=2; double grandProducts=0, grandAlcohol=0;
        for(MainActivity.Receipt receipt: receipts){
            double productTotal=0, alcoholTotal=0;
            for(MainActivity.Row x: receipt.rows){
                sheet.append("<row r=\"").append(rowNum).append("\">");
                sheet.append(inlineCell(1,rowNum,receipt.date,0));
                if(x.alcohol){
                    alcoholTotal+=x.sum;
                    sheet.append(blank(2)).append(blank(3)).append(blank(4));
                    sheet.append(inlineCell(5,rowNum,x.name,3));
                    sheet.append(numberCell(6,rowNum,x.unit,0));
                    sheet.append(numberCell(7,rowNum,x.qty,2));
                    sheet.append(numberCell(8,rowNum,x.sum,4));
                } else {
                    productTotal+=x.sum;
                    sheet.append(inlineCell(2,rowNum,x.name,1));
                    sheet.append(numberCell(3,rowNum,x.unit,0));
                    sheet.append(numberCell(4,rowNum,x.qty,2));
                    sheet.append(blank(5)).append(blank(6)).append(blank(7));
                    sheet.append(numberCell(8,rowNum,x.sum,4));
                }
                sheet.append("</row>"); rowNum++;
            }
            grandProducts+=productTotal; grandAlcohol+=alcoholTotal;
        }
        sheet.append("<row r=\"").append(rowNum).append("\">");
        sheet.append(inlineCell(1,rowNum,"ИТОГО",4)).append(blank(2));
        sheet.append(numberCell(3,rowNum,grandProducts,0)).append(blank(4));
        sheet.append(inlineCell(5,rowNum,"ИТОГО",4));
        sheet.append(numberCell(6,rowNum,grandAlcohol,0)).append(blank(7));
        sheet.append(numberCell(8,rowNum,grandProducts+grandAlcohol,4));
        sheet.append("</row></sheetData>");
        sheet.append("<cols><col min=\"1\" max=\"1\" width=\"15\"/><col min=\"2\" max=\"2\" width=\"34\"/><col min=\"3\" max=\"3\" width=\"13\"/><col min=\"4\" max=\"4\" width=\"13\"/><col min=\"5\" max=\"5\" width=\"34\"/><col min=\"6\" max=\"6\" width=\"13\"/><col min=\"7\" max=\"7\" width=\"13\"/><col min=\"8\" max=\"8\" width=\"15\"/></cols>");
        sheet.append("<autoFilter ref=\"A1:H").append(rowNum).append("\"/><pageMargins left=\"0.25\" right=\"0.25\" top=\"0.5\" bottom=\"0.5\" header=\"0\" footer=\"0\"/></worksheet>");

        String styles="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><numFmts count=\"1\"><numFmt numFmtId=\"4\" formatCode=\"0.00\"/></numFmts><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"5\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF9DC3E6\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFB7E1B0\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFF9999\"/></patternFill></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FFFFC000\"/></patternFill></fill></fills><cellXfs count=\"6\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"1\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"2\"/><xf numFmtId=\"0\" fontId=\"0\" fillId=\"3\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"4\"/><xf numFmtId=\"4\" fontId=\"0\" fillId=\"0\"/></cellXfs></styleSheet>";
        String content="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>";
        String rels="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>";
        String wb="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Расходы\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
        String wbr="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>";
        try(OutputStream out=resolver.openOutputStream(uri); ZipOutputStream z=new ZipOutputStream(out)){
            put(z,"[Content_Types].xml",content); put(z,"_rels/.rels",rels); put(z,"xl/workbook.xml",wb); put(z,"xl/_rels/workbook.xml.rels",wbr); put(z,"xl/styles.xml",styles); put(z,"xl/worksheets/sheet1.xml",sheet.toString());
        }
    }
    private static String blank(int c){ return "<c r=\""+col(c)+"\"/>"; }
    private static String inlineCell(int c,int r,String v,int style){ return "<c r=\""+col(c)+r+"\" s=\""+style+"\" t=\"inlineStr\"><is><t>"+esc(v)+"</t></is></c>"; }
    private static String numberCell(int c,int r,double v,int style){ return "<c r=\""+col(c)+r+"\" s=\""+style+"\"><v>"+String.format(Locale.US,"%.2f",v)+"</v></c>"; }
}
